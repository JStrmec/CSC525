# Salary Polynomial Regression

To run the program use `make run`. Or `python polynomial_salary_regressor.py`

You will have the input appear. And then the prediction will be made with `Predicted salary: $`: 
```
Enter years of experience to predict salary (or 'exit' to quit):
```