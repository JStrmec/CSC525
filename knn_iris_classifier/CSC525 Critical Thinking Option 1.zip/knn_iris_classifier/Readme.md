# KNN Iris Classifier

To run the program use `make run`. Or `python iris_knn.py`

You will have the inputs appear one line at a time. And then the prediction will be made with `Predicted Iris type:`: 
```
Enter sepal length, sepal width, petal length, and petal width:
Sepal Length (cm): 
Sepal Width (cm):
Petal Length (cm): 
Petal Width (cm): 
Do you want to specify the value of k? (yes/no)
Value of k (default is 3):
```